# Rob Green Portfolio

This is a personalised fork of the uploaded portfolio template.

## Quick Start

```bash
# install dependencies
npm install

# run dev server
npm run dev

# build for production
npm run build

# serve the production build if available
npm run start
```

## Deploying to GitHub

1. Create a new empty repo on GitHub. Do not add a README or licence.
2. In this folder run:
```bash
git init
git branch -M main
git add .
git commit -m "Initial commit of Rob portfolio"
git remote add origin YOUR_REPO_SSH_OR_HTTPS_URL
git push -u origin main
```


## Personalisation
This copy updates the name, location, summary and skills to Rob Green. Edit `src/data/resume.tsx` to tweak content and `public` for images.
